package cruxui.android.lib.ui.components.buttons.navigation.simple.tokens

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import cruxui.android.lib.R
import cruxui.android.lib.compositions.LocalFontFamily
import cruxui.android.lib.compositions.LocalLibraryColorTokens
import cruxui.android.lib.compositions.LocalLibraryIcons
import cruxui.android.lib.compositions.LocalLibraryTypography
import cruxui.android.lib.tokens.base.ColorToken
import cruxui.android.lib.tokens.base.IconToken
import cruxui.android.lib.tokens.base.TypographyToken
import cruxui.android.lib.tokens.fonts.TextAlignTokens
import cruxui.android.lib.ui.components.buttons.navigation.simple.variant.ButtonNavigationVariant
import cruxui.android.lib.ui.components.buttons.navigation.simple.variant.ButtonNavigationVariantResolver
import cruxui.android.lib.ui.components.buttons.simple.tokens.ButtonTokensResolver

/**
 * Resuelve los tokens del ButtonNavigation desde los tokens visuales de Button simple.
 *
 * Mantiene la estructura estandar de resolvers: resolve, fromLibrary y fromMaterial.
 */
object ButtonNavigationTokensResolver {

    @get:Composable
    val primary: ButtonNavigationTokens
        get() = resolve(variant = ButtonNavigationVariant.PRIMARY)

    @get:Composable
    val secondary: ButtonNavigationTokens
        get() = resolve(variant = ButtonNavigationVariant.SECONDARY)

    /**
     * Resuelve tokens visuales para la variante indicada y aplica overrides opcionales.
     */
    @Composable
    fun resolve(
        variant: ButtonNavigationVariant = ButtonNavigationVariant.PRIMARY,
        tokens: ButtonNavigationTokens? = null,
        override: ButtonNavigationTokensOverride? = null,
    ): ButtonNavigationTokens {
        val base = tokens ?: when {
            hasLibraryTokens() -> fromLibrary(variant)
            else -> fromMaterial(variant)
        }

        return base.merge(override)
    }

    /**
     * Detecta si el Design System esta correctamente inyectado.
     */
    @Composable
    private fun hasLibraryTokens(): Boolean {
        return runCatching {
            LocalLibraryColorTokens.current
            LocalLibraryTypography.current
            LocalLibraryIcons.current
            LocalFontFamily.current
            true
        }.getOrDefault(false)
    }

    /**
     * Resuelve tokens desde el Design System y mapea la variante visual al Button simple base.
     */
    @Composable
    private fun fromLibrary(variant: ButtonNavigationVariant): ButtonNavigationTokens {
        val colors = LocalLibraryColorTokens.current
        val typography = LocalLibraryTypography.current
        val fontFamily = LocalFontFamily.current
        val icons = LocalLibraryIcons.current

        if (ButtonNavigationVariantResolver.isSquare(variant)) {
            return when (variant) {
                ButtonNavigationVariant.PRIMARYSQUARE -> ButtonNavigationTokens(
                    contentColor = colors.fgOnInverse,
                    contentPressColor = colors.fgOnInverse,
                    containerColor = colors.brandPrimary,
                    disabledContentColor = colors.fgSubtle,
                    disabledContainerColor = colors.bgMuted,
                    hoverContainerColor = colors.brandPrimaryHover,
                    borderContainerColor = colors.brandPrimary,
                    borderDisabledColor = colors.borderDefault,
                    iconToken = icons.arrows.keyboardBackspaceRight,
                    loadingIconToken = icons.arrows.sync,
                    iconColor = colors.fgOnInverse,
                    typographyToken = typography.legal.copy(
                        textAlign = TextAlignTokens.Center
                    ),
                    fontFamilyToken = fontFamily,
                )

                ButtonNavigationVariant.SECONDARYSQUARE -> ButtonNavigationTokens(
                    contentColor = colors.brandPrimary,
                    contentPressColor = colors.fgOnInverse,
                    containerColor = colors.errorFillSoft,
                    disabledContentColor = colors.fgSubtle,
                    disabledContainerColor = colors.bgMuted,
                    hoverContainerColor = colors.brandPrimaryHover,
                    borderContainerColor = colors.brandPrimary,
                    borderDisabledColor = colors.borderDefault,
                    iconToken = icons.arrows.keyboardBackspaceLeft,
                    loadingIconToken = icons.arrows.sync,
                    iconColor = colors.brandPrimary,
                    typographyToken = typography.legal.copy(
                        textAlign = TextAlignTokens.Center
                    ),
                    fontFamilyToken = fontFamily,
                )

                ButtonNavigationVariant.PRIMARY,
                ButtonNavigationVariant.SECONDARY -> error("Unsupported square variant: $variant")
            }
        }

        val buttonTokens = ButtonTokensResolver.resolve(
            variant = ButtonNavigationVariantResolver.resolve(variant),
        )

        val iconToken = when (variant) {
            ButtonNavigationVariant.PRIMARY -> icons.arrows.keyboardBackspaceRight

            ButtonNavigationVariant.SECONDARY -> icons.arrows.keyboardBackspaceLeft

            ButtonNavigationVariant.PRIMARYSQUARE,
            ButtonNavigationVariant.SECONDARYSQUARE -> error("Unsupported label variant: $variant")
        }

        return ButtonNavigationTokens(
            contentColor = buttonTokens.textColor,
            contentPressColor = buttonTokens.pressedTextColor,
            containerColor = buttonTokens.background,
            disabledContentColor = buttonTokens.disabledTextColor,
            disabledContainerColor = buttonTokens.disabledBackground,
            hoverContainerColor = buttonTokens.pressedBackground,
            borderContainerColor = buttonTokens.border,
            borderDisabledColor = buttonTokens.disabledBorder,
            iconToken = iconToken,
            loadingIconToken = icons.arrows.sync,
            iconColor = buttonTokens.textColor,
            typographyToken = buttonTokens.typography,
            fontFamilyToken = buttonTokens.fontFamily,
        )
    }

    /**
     * Fallback Material Design para uso fuera del tema del DS.
     */
    @Composable
    private fun fromMaterial(variant: ButtonNavigationVariant): ButtonNavigationTokens {
        // La compatibilidad Material de navegación no depende del nuevo Button, que exige LibraryTheme.
        val fontFamily = LocalFontFamily.current
        val scheme = MaterialTheme.colorScheme
        val backRightIcon = IconToken("ic_keyboard_backspace_right", R.drawable.ic_keyboard_backspace_right)
        val backLeftIcon = IconToken("ic_keyboard_backspace_left", R.drawable.ic_keyboard_backspace_left)
        val syncIcon = IconToken("ic_sync", R.drawable.ic_sync)

        fun colorToken(value: Color): ColorToken =
            ColorToken(value.value.toLong())

        fun pressedPrimary(): ColorToken {
            val overlay = scheme.onPrimary.copy(alpha = 0.12f)
            val mixed = lerp(scheme.primary, overlay, 0.5f)
            return colorToken(mixed)
        }

        if (ButtonNavigationVariantResolver.isSquare(variant)) {
            val legalTypography = TypographyToken(
                fontSize = 12f,
                lineHeight = 18f,
                letterSpacing = 0f,
                weight = 400,
                italic = false,
            )

            return when (variant) {
                ButtonNavigationVariant.PRIMARYSQUARE -> ButtonNavigationTokens(
                    contentColor = colorToken(scheme.onPrimary),
                    contentPressColor = colorToken(scheme.onPrimary),
                    containerColor = colorToken(scheme.primary),
                    disabledContentColor = colorToken(scheme.onSurfaceVariant),
                    disabledContainerColor = colorToken(scheme.surfaceVariant),
                    hoverContainerColor = pressedPrimary(),
                    borderContainerColor = colorToken(scheme.primary),
                    borderDisabledColor = colorToken(scheme.outline),
                    iconToken = backRightIcon,
                    loadingIconToken = syncIcon,
                    iconColor = colorToken(scheme.onPrimary),
                    typographyToken = legalTypography,
                    fontFamilyToken = fontFamily,
                )

                ButtonNavigationVariant.SECONDARYSQUARE -> ButtonNavigationTokens(
                    contentColor = colorToken(scheme.primary),
                    contentPressColor = colorToken(scheme.onPrimary),
                    containerColor = colorToken(scheme.primaryContainer),
                    disabledContentColor = colorToken(scheme.onSurfaceVariant),
                    disabledContainerColor = colorToken(scheme.surfaceVariant),
                    hoverContainerColor = pressedPrimary(),
                    borderContainerColor = colorToken(scheme.primary),
                    borderDisabledColor = colorToken(scheme.outline),
                    iconToken = backLeftIcon,
                    loadingIconToken = syncIcon,
                    iconColor = colorToken(scheme.primary),
                    typographyToken = legalTypography,
                    fontFamilyToken = fontFamily,
                )

                ButtonNavigationVariant.PRIMARY,
                ButtonNavigationVariant.SECONDARY -> error("Unsupported square variant: $variant")
            }
        }

        val iconToken = when (variant) {
            ButtonNavigationVariant.PRIMARY -> backRightIcon
            ButtonNavigationVariant.SECONDARY -> backLeftIcon
            ButtonNavigationVariant.PRIMARYSQUARE,
            ButtonNavigationVariant.SECONDARYSQUARE -> error("Unsupported label variant: $variant")
        }

        // Receta Material que antes aportaba ButtonTokensResolver.fromMaterial.
        val primary = variant == ButtonNavigationVariant.PRIMARY
        val content = colorToken(if (primary) scheme.onPrimary else scheme.primary)
        return ButtonNavigationTokens(
            contentColor = content,
            contentPressColor = colorToken(scheme.onPrimary),
            containerColor = colorToken(if (primary) scheme.primary else scheme.surface),
            disabledContentColor = colorToken(scheme.onSurface.copy(alpha = 0.38f)),
            disabledContainerColor = colorToken(scheme.onSurface.copy(alpha = 0.12f)),
            hoverContainerColor = pressedPrimary(),
            borderContainerColor = colorToken(if (primary) scheme.outline else scheme.primary),
            borderDisabledColor = colorToken(scheme.outlineVariant),
            iconToken = iconToken,
            loadingIconToken = syncIcon,
            iconColor = content,
            typographyToken = TypographyToken(
                fontSize = 14f,
                lineHeight = 20f,
                letterSpacing = 0.1f,
                weight = 500,
                italic = false,
            ),
            fontFamilyToken = fontFamily,
        )
    }
}
