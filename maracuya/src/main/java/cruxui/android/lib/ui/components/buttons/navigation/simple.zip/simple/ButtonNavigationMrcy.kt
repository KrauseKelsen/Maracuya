package cruxui.android.lib.ui.components.buttons.navigation.simple

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import cruxui.android.lib.ui.components.buttons.navigation.simple.behavior.ButtonNavigationBehavior
import cruxui.android.lib.ui.components.buttons.navigation.simple.behavior.ButtonNavigationBehaviorResolver
import cruxui.android.lib.ui.components.buttons.navigation.simple.core.ButtonNavigationLoadingScope
import cruxui.android.lib.ui.components.buttons.navigation.simple.tokens.ButtonNavigationTokens
import cruxui.android.lib.ui.components.buttons.navigation.simple.tokens.ButtonNavigationTokensOverride
import cruxui.android.lib.ui.components.buttons.navigation.simple.tokens.ButtonNavigationTokensResolver
import cruxui.android.lib.ui.components.buttons.navigation.simple.tokensrender.ButtonNavigationTokensRenderResolver
import cruxui.android.lib.ui.components.buttons.navigation.simple.variant.ButtonNavigationVariant
import cruxui.android.lib.ui.components.buttons.navigation.simple.variant.ButtonNavigationVariantResolver
import cruxui.android.lib.ui.components.labels.LabelMrcy
import cruxui.android.lib.ui.components.labels.tokens.LabelTokensOverride
import cruxui.android.lib.ui.utils.compose.collectPressedAsState
import cruxui.android.lib.utils.composeadapters.ColorComposeAdapter
import cruxui.android.lib.utils.composeadapters.FontFamiliesComposeAdapter
import cruxui.android.lib.utils.composeadapters.TypographyComposeAdapter

/**
 * Construye el boton de navegacion a partir de behavior, variant y tokens resueltos.
 *
 * Orquesta las capas del componente y delega la logica de seleccion a sus resolvers.
 */
@Composable
fun ButtonNavigationMrcy(
    modifier: Modifier = Modifier,
    label: String? = null,
    onClick: () -> Unit,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(100.dp),
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    variant: ButtonNavigationVariant = ButtonNavigationVariant.PRIMARY,
    buttonNavigationBehavior: ButtonNavigationBehavior = ButtonNavigationBehavior.Default,
    buttonNavigationTokens: ButtonNavigationTokens? = null,
    buttonNavigationTokensOverride: ButtonNavigationTokensOverride? = null,
    onTrailingClick: (ButtonNavigationLoadingScope.() -> Unit)? = null,
    onLoadingClick: (ButtonNavigationLoadingScope.() -> Unit)? = null,
) {
    val tokens = ButtonNavigationTokensResolver.resolve(
        variant = variant,
        tokens = buttonNavigationTokens,
        override = buttonNavigationTokensOverride,
    )

    val behaviorState = ButtonNavigationBehaviorResolver.resolve(
        behavior = buttonNavigationBehavior,
        enabled = enabled,
        onClick = onClick,
        onLoadingClick = onLoadingClick ?: onTrailingClick,
    )

    val pressed by interactionSource.collectPressedAsState()
    val renderTokens = ButtonNavigationTokensRenderResolver.resolve(
        tokens = tokens,
        enabled = enabled,
        pressed = pressed,
        isLoading = behaviorState.isLoading,
        canClick = behaviorState.canClick,
        showIcon = behaviorState.showIcon,
    )

    val textStyle = TypographyComposeAdapter.toTextStyle(
        token = renderTokens.typographyToken,
        fontFamily = FontFamiliesComposeAdapter.toCompose(renderTokens.fontFamilyToken),
    )

    val buttonModifier = ButtonNavigationVariantResolver.resolveButtonModifier(
        variant = variant,
        modifier = modifier,
    )
    val buttonShape = ButtonNavigationVariantResolver.resolveButtonShape(
        variant = variant,
        shape = shape,
    )
    val buttonLabel = ButtonNavigationVariantResolver.resolveButtonLabel(
        variant = variant,
        label = label,
    )
    val bottomLabel = ButtonNavigationVariantResolver.resolveBottomLabel(
        variant = variant,
        label = label,
    )
    val bottomLabelSpacing = ButtonNavigationVariantResolver.resolveBottomLabelSpacing(variant)
    val iconAtEnd = ButtonNavigationVariantResolver.resolveIconAtEnd(variant)

    val button: @Composable () -> Unit = {
        Button(
            onClick = behaviorState.onClick,
            enabled = behaviorState.canClick,
            modifier = buttonModifier,
            shape = buttonShape,
            border = BorderStroke(1.dp, ColorComposeAdapter.toComposeColor(renderTokens.borderColor)),
            interactionSource = interactionSource,
            colors = ButtonDefaults.buttonColors(
                containerColor = ColorComposeAdapter.toComposeColor(renderTokens.containerColor),
                contentColor = ColorComposeAdapter.toComposeColor(renderTokens.contentColor),
                disabledContainerColor = ColorComposeAdapter.toComposeColor(renderTokens.disabledContainerColor),
                disabledContentColor = ColorComposeAdapter.toComposeColor(renderTokens.disabledContentColor),
            ),
        ) {
            ButtonNavigationContent(
                label = buttonLabel,
                tokens = renderTokens,
                iconAtEnd = iconAtEnd,
                behaviorState = behaviorState,
                contentColor = ColorComposeAdapter.toComposeColor(renderTokens.contentColor),
                iconColor = ColorComposeAdapter.toComposeColor(renderTokens.iconColor),
                textStyle = textStyle,
            )
        }
    }

    if (bottomLabel != null) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            button()
            Spacer(modifier = Modifier.height(bottomLabelSpacing))
            LabelMrcy(
                text = bottomLabel,
                labelTokensOverride = LabelTokensOverride(
                    labelTypography = renderTokens.typographyToken,
                    fontFamily = renderTokens.fontFamilyToken,
                ),
                limitMaxLabel = false,
            )
        }
    } else {
        button()
    }
}
