package com.example.mylibrary.ui.components.buttons.secondary

import androidx.compose.runtime.Composable
import com.example.mylibrary.compositions.LocalFontFamily
import com.example.mylibrary.compositions.LocalLibraryColorTokens
import com.example.mylibrary.compositions.LocalLibraryTypography

object SecondaryButtonTokensResolver {

    @Composable
    fun resolve(
        override: SecondaryButtonTokens? = null
    ): SecondaryButtonTokens {
        override?.let { return it }

        return when {
            hasLibraryTokens() -> fromLibrary()
            else -> fromMaterial()
        }
    }

    @Composable
    private fun hasLibraryTokens(): Boolean {
        return runCatching {
            LocalLibraryColorTokens.current
            LocalLibraryTypography.current
            LocalFontFamily.current
            true
        }.getOrDefault(false)
    }

    /**
     * Deriva ButtonTokens desde LibraryColorTokens (semántica corporativa).
     * Mantener SRP: esta función solo mapea semántica -> tokens del componente.
     */
    @Composable
    fun fromLibrary(): SecondaryButtonTokens {
        val colors = LocalLibraryColorTokens.current
        val typography = LocalLibraryTypography.current
        val fontFamily = LocalFontFamily.current
        return SecondaryButtonTokens(
            containerColor = colors.bgBase,
            contentColor = colors.fgOnInverseAux, // TODO este color debe ser brandSecondary
            contentPressColor = colors.fgOnInverse,
            hoverContainerColor = colors.brandPrimaryHover,
            disabledContainerColor = colors.bgMuted,
            disabledContentColor = colors.fgMuted,
            borderContainerColor = colors.brandPrimary,
            borderDisabledColor = colors.borderDefault,
            textTypography = typography.buttons, // semántica corporativa para botones
            fontFamilyToken = fontFamily
        )
    }

    /**
     * Deriva ButtonTokens desde el ColorScheme activo (Material).
     * Útil cuando la librería host ha solicitado `useMaterial = true`.
     */
    @Composable
    fun fromMaterial(): SecondaryButtonTokens = fromLibrary()
}